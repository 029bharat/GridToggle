import {
  ALL_EMP_REQUEST,
  ALL_EMP_FAILURE,
  ALL_EMP_SUCCESS,
  EMP_FAILURE,
  EMP_REQUEST,
  EMP_SUCCESS,
} from '../constants/ActionTypes';
import {BASE_URL, ALL_EMP, EMP_DETAIL} from '../constants/Common';
import axiosClient from '../network';
export function getEmpList() {
  return async (dispatch) => {
    try {
      await dispatch({
        type: ALL_EMP_REQUEST,
      });
      const apiReq = await axiosClient({
        url: BASE_URL,
        method: 'GET',
      });
      if (apiReq.status == 200) {
        dispatch({
          type: ALL_EMP_SUCCESS,
          payload: apiReq.data,
        });
      } else {
        dispatch({
          type: ALL_EMP_FAILURE,
          payload: null,
        });
      }
      return apiReq || [];
    } catch (error) {
      console.error(error);
      dispatch({
        type: ALL_EMP_FAILURE,
        payload: null,
      });
    }
  };
}
export function getEmployee(empId = 0) {
  return async (dispatch) => {
    try {
      await dispatch({
        type: EMP_REQUEST,
      });
      const apiReq = await axiosClient({
        url: BASE_URL + EMP_DETAIL + empId,
        method: 'GET',
      });
      if (apiReq.status == 200) {
        dispatch({
          type: EMP_SUCCESS,
          payload: apiReq.data.data,
        });
      } else {
        dispatch({
          type: EMP_FAILURE,
          payload: null,
        });
      }
      return apiReq || [];
    } catch (error) {
      console.error(error);
      dispatch({
        type: EMP_FAILURE,
        payload: null,
      });
    }
  };
}
