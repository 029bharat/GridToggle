import React, {useState} from 'react';
import {View, Text, StyleSheet, Image, ImageBackground} from 'react-native';
import {TouchableWithoutFeedback} from 'react-native-gesture-handler';
const loaderIcon = require('../assets/images/downloading.png');
const styles = StyleSheet.create({
  cardContainer: {
    justifyContent: 'center',
    flexDirection: 'row',
    width: '100%',
    paddingVertical: 10,
    alignItems: 'center',
  },
  itemText: {
    textAlign: 'center',
  },
  image: {
    height: 100,
    width: 100,
  },
  textRow: {flexDirection: 'row'},
});
const CardView = props => {
  const {item, index, toggleModal} = props;
  return (
    <TouchableWithoutFeedback
      key={item.id}
      style={[
        styles.cardContainer,
        {
          backgroundColor: index % 2 == 0 ? 'grey' : 'white',
        },
      ]}
      onPress={() => toggleModal(item ? item.url : null)}>
      <View
        style={{
          alignItems: 'center',
          flex: 1,
        }}>
        <Image
          defaultSource={loaderIcon}
          resizeMo
          de={'contain'}
          source={{uri: item.thumbnailUrl}}
          style={styles.image}
        />
        <View style={styles.textRow}>
          <Text
            numberOfLines={5}
            style={[
              {
                color: index % 2 == 0 ? 'white' : 'black',
              },
              styles.itemText,
            ]}>
            {item.title}
          </Text>
        </View>
      </View>
    </TouchableWithoutFeedback>
  );
};
export default CardView;
