import React from 'react';
import {FlatList, StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  listContainer: {
    paddingTop: 10,
    justifyContent: 'center',
  },
});
const EmptyView = props => {
  const {
    keyExtractor,
    columnCount,
    ListEmptyComponent,
    extraData,
    data,
    renderItem,
  } = props;
  return (
    <FlatList
      key={columnCount}
      contentContainerStyle={styles.listContainer}
      data={data}
      keyExtractor={keyExtractor}
      numColumns={columnCount}
      extraData={extraData}
      renderItem={renderItem}
      ListEmptyComponent={() => ListEmptyComponent()}
      removeClippedSubviews={true}
      windowSize={10}
      initialNumToRender={10}
      maxToRenderPerBatch={3}
    />
  );
};
export default EmptyView;
