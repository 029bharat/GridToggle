import React from 'react';
import {View, Text} from 'react-native';

const EmptyView = () => {
  return (
    <View>
      <Text>No data found</Text>
    </View>
  );
};
export default EmptyView;
