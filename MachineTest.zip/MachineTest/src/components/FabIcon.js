import React from 'react';
import {View, StyleSheet, TouchableWithoutFeedback, Image} from 'react-native';
const listIcon = require('../assets/images/list.png');
const gridIcon = require('../assets/images/grid.png');
const styles = StyleSheet.create({
  iconContainer: {
    position: 'absolute',
    justifyContent: 'flex-end',
    top: 0,
    right: 40,
    bottom: 40,
  },
  image: {
    height: 50,
    width: 50,
  },
});

const Item = props => {
  const {isList = true, toggleView = () => {}, isEmpty = false} = props;
  return isEmpty ? (
    <View style={styles.iconContainer}>
      <TouchableWithoutFeedback onPress={() => toggleView()}>
        <Image
          resizeMode={'contain'}
          source={!isList ? listIcon : gridIcon}
          style={styles.image}
        />
      </TouchableWithoutFeedback>
    </View>
  ) : null;
};
export default Item;
