import React from 'react';
import {
  Modal,
  StyleSheet,
  View,
  TouchableWithoutFeedback,
  Animated,
} from 'react-native';
import {PinchGestureHandler, State} from 'react-native-gesture-handler';
const loaderIcon = require('../assets/images/downloading.png');
const ModalView = props => {
  const {isVisible, closeModal, imageURI} = props;
  scale = new Animated.Value(1);

  onZoomEvent = Animated.event(
    [
      {
        nativeEvent: {scale: this.scale},
      },
    ],
    {
      useNativeDriver: true,
    },
  );

  onZoomStateChange = event => {
    if (event.nativeEvent.oldState === State.ACTIVE) {
      Animated.spring(this.scale, {
        toValue: 1,
        useNativeDriver: true,
      }).start();
    }
  };
  return (
    <View style={styles.centeredView}>
      <Modal
        animationType="slide"
        transparent={true}
        visible={isVisible}
        onRequestClose={() => closeModal()}>
        <TouchableWithoutFeedback onPress={() => closeModal()}>
          <View style={{...styles.centeredView}}>
            <View style={styles.modalView}>
              <View style={{...styles.openButton}}>
                <PinchGestureHandler
                  onGestureEvent={this.onZoomEvent}
                  onHandlerStateChange={this.onZoomStateChange}>
                  <Animated.Image
                    defaultSource={loaderIcon}
                    resizeMode={'contain'}
                    source={{uri: imageURI}}
                    style={{...styles.image, transform: [{scale: this.scale}]}}
                  />
                </PinchGestureHandler>
              </View>
            </View>
          </View>
        </TouchableWithoutFeedback>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 22,
  },
  modalView: {
    margin: 20,
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 35,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },

    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  openButton: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  image: {
    height: 250,
    width: 250,
  },
});

export default ModalView;
