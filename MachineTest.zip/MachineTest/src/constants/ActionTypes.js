export const ALL_EMP_REQUEST = 'ALL_EMP_REQUEST';
export const ALL_EMP_SUCCESS = 'ALL_EMP_SUCCESS';
export const ALL_EMP_FAILURE = 'ALL_EMP_FAILURE';

export const EMP_REQUEST = 'EMP_REQUEST';
export const EMP_SUCCESS = 'EMP_SUCCESS';
export const EMP_FAILURE = 'EMP_FAILURE';