export const BASE_URL = 'https://jsonplaceholder.typicode.com/photos';
export const ALL_EMP = 'employees';
export const EMP_DETAIL = 'employee/';
