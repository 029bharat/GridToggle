import axios from 'axios';
import {BASE_URL, ALL_EMP} from '../constants/Common';

axios.defaults.headers.post['Content-Type'] = 'application/json';
axios.defaults.headers.post['Accept'] = 'application/json';
axios.defaults.headers.post['Access-Control-Allow-Origin'] = '*';
axios.defaults.headers.post['Access-Control-Allow-Methods'] =
  'GET,PUT,POST,PATCH,DELETE,OPTIONS';
axios.defaults.headers.post['Access-Control-Allow-Credentials'] = 'true';
axios.defaults.headers.post['Access-Control-Allow-Headers'] =
  'Access-Control-*, Origin, X-Requested-With, Content-Type, Accept, Authorization';

const instance = axios.create({
  baseURL: BASE_URL,
  timeout: 6000,
});
instance.interceptors.request.use(
  async config => {
    return config
  },
  error => {
    return Promise.reject(error);
  },
);

instance.interceptors.response.use(
  response => {
    // do something with the response data
    return response;
  },
  error => {
    // handle the response error
    return Promise.reject(error);
  },
);
export default instance;
