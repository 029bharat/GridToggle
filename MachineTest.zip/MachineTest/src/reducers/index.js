/* eslint-disable module-resolver/use-alias */
import {
  ALL_EMP_REQUEST,
  ALL_EMP_FAILURE,
  ALL_EMP_SUCCESS,
  EMP_SUCCESS,
  EMP_REQUEST,
  EMP_FAILURE,
} from '../constants/ActionTypes';
const INITIAL_STATE = {
  isAllEmpSuccess: false,
  isAllEmpLoading: false,
  AllEmp: null,
  isAllEmpFail: false,

  isEmpLoading: false,
  isEmpSuccess: false,
  EmpData: null,
  isEmpFail: false,
};
function HomeReducer(state = INITIAL_STATE, action) {
  switch (action.type) {
    case ALL_EMP_REQUEST:
      return Object.assign({}, state, {
        isAllEmpFail: false,
        isAllEmpSuccess: false,
        AllEmp: null,
        isAllEmpLoading: true,
      });
    case ALL_EMP_SUCCESS:
      return Object.assign({}, state, {
        isAllEmpLoading: false,
        isAllEmpSuccess: true,
        AllEmp: action.payload,
        isAllEmpFail: false,
      });
    case ALL_EMP_FAILURE:
      return Object.assign({}, state, {
        isAllEmpLoading: false,
        isAllEmpSuccess: false,
        AllEmp: null,
        isAllEmpFail: true,
      });

    case EMP_REQUEST:
      return Object.assign({}, state, {
        // isEmpLoading: false,
        isEmpSuccess: false,
        EmpData: null,
        isEmpFail: false,
        isEmpLoading: true,
      });
    case EMP_SUCCESS:
      return Object.assign({}, state, {
        isEmpLoading: false,
        isEmpSuccess: true,
        EmpData: action.payload,
        isEmpFail: false,
      });
    case EMP_FAILURE:
      return Object.assign({}, state, {
        isEmpLoading: false,
        isEmpSuccess: false,
        EmpData: null,
        isEmpFail: true,
      });
    default:
      return state;
  }
}
export default HomeReducer;
