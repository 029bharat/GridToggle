import React, { useEffect} from 'react';
import {
  View,
  Text,
  ActivityIndicator,
  StyleSheet,
} from 'react-native';
import {getEmployee} from '../../actions';

import {
  withNavigation,
} from 'react-navigation';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  empText: {
    fontSize: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'grey',
    textAlign: 'center',
  },
});
function Details(props) {

  useEffect(() => {
    //  componentDidmount
    props.getEmployee(props.navigation.state.params.empId);
  }, []);

  const {EmpData, isEmpLoading} = props;
  return (
    <View style={styles.container}>
      {isEmpLoading ? (
        <ActivityIndicator />
      ) : EmpData ? (
        <Text style={styles.empText}>{`Name: ${
          EmpData.employee_name
        } \n Salary: $ ${EmpData.employee_salary} \n Age:${
          EmpData.employee_age
        } yrs`}</Text>
      ) : (
        <Text>No data found</Text>
      )}
    </View>
  );
}

function mapStateToProps({HomeReducer}) {
  return {
    isEmpLoading: HomeReducer.isEmpLoading,
    isEmpSuccess: HomeReducer.isEmpSuccess,
    EmpData: HomeReducer.EmpData,
    isEmpFail: HomeReducer.isEmpFail,
  };
}

function mapDispatchToProps(dispatch) {
  return bindActionCreators({getEmployee}, dispatch);
}

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(withNavigation(Details));
