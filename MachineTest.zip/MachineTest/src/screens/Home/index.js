import React, {useEffect, useCallback, useMemo, useState} from 'react';
import {connect} from 'react-redux';
import {View, ActivityIndicator, StyleSheet} from 'react-native';
import {getEmpList} from '../../actions';
import {withNavigation} from 'react-navigation';
import {bindActionCreators} from 'redux';
import {Card, FabIcon, EmptyData, CustomList, Modal} from '../../components';

const styles = StyleSheet.create({
  container: {flexGrow: 1.2, marginTop: 10, flex: 1},
});

function Home(props) {
  useEffect(() => {
    props.getEmpList();
  }, []);
  const getImage = url => {
    toggleIsModal(true), setModalUri(url);
  };
  const {isAllEmpLoading, AllEmp} = props;
  const [isListView, toggleisListView] = useState(true);
  const [isModal, toggleIsModal] = useState(false);
  const [isModalUri, setModalUri] = useState(false);
  const keyExtractor = useCallback((item, index) => {
    return item ? item.id : index;
  }, []);
  const renderItem = useCallback(({item, index}) => {
    return <Card item={item} index={index} toggleModal={getImage} />;
  }, []);
  const columnCount = isListView ? 1 : 2;

  return (
    <View style={styles.container}>
      {isAllEmpLoading ? (
        <ActivityIndicator />
      ) : (
        <View>
          <CustomList
            columnCount={columnCount}
            data={AllEmp}
            keyExtractor={keyExtractor}
            numColumns={columnCount}
            extraData={props}
            ListEmptyComponent={() => <EmptyData />}
            renderItem={renderItem}
          />
          <FabIcon
            isEmpty={AllEmp && AllEmp.length > 0}
            isList={isListView}
            toggleView={() => toggleisListView(!isListView)}
          />
        </View>
      )}
      <Modal
        isVisible={isModal}
        closeModal={() => (isModal ? toggleIsModal(false) : {})}
        imageURI={isModalUri}
      />
    </View>
  );
}

function mapStateToProps({HomeReducer}) {
  return {
    isAllEmpLoading: HomeReducer.isAllEmpLoading,
    isAllEmpSuccess: HomeReducer.isAllEmpSuccess,
    AllEmp: HomeReducer.AllEmp,
    isAllEmpFail: HomeReducer.isAllEmpFail,
  };
}

function mapDispatchToProps(dispatch) {
  return bindActionCreators({getEmpList}, dispatch);
}

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(withNavigation(Home));
