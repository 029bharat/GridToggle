import { createStore, applyMiddleware,combineReducers } from 'redux';
import thunk from 'redux-thunk';
import logger from 'redux-logger'
import HomeReducer from '../reducers';
const rootReducer = combineReducers(
    { HomeReducer: HomeReducer }
);
export default function setup() {
    let store = createStore(rootReducer, applyMiddleware(thunk,logger))
    return store
}